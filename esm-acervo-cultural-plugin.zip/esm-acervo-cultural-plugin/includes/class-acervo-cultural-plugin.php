<?php
class Acervo_Cultural_Plugin {

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }

    public function register_rest_routes() {
        require_once plugin_dir_path(__FILE__) . 'class-acervo-cultural-rest-controller.php';
        $controller = new Acervo_Cultural_REST_Controller();
        $controller->register_routes();
    }
}

new Acervo_Cultural_Plugin();
