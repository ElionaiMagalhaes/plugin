<?php
class Acervo_Cultural_REST_Controller extends WP_REST_Controller {

    public function register_routes() {
        $version = '1';
        $namespace = 'acervo-culutural/v' . $version;
        $base = 'obras';

        register_rest_route($namespace, '/' . $base, array(
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array($this, 'create_obras'),
                'permission_callback' => array($this, 'create_obras_permission_check'),
                'args'                => $this->get_endpoint_args_for_item_schema(true),
            ),
        ));

        // Defina outros endpoints aqui (atualização, leitura, exclusão)
    }

    public function create_obras($request) {
        // Lógica para criar obras aqui
    }

    public function create_obras_permission_check($request) {
        // Verifique permissões para criar obras aqui
        return true;
    }
}
