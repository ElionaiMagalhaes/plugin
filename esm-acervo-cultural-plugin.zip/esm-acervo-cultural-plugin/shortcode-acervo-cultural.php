<?php
// Função para renderizar o shortcode
function acervo_cultural_shortcode() {
    ?>
    <div id="app">
        <!-- Aqui será renderizado o conteúdo da aplicação VueJS -->
    </div>

    <script src="<?php echo plugins_url('acervo-cultural-app/dist/js/app.js'); ?>"></script>
    <?php
}

// Registra o shortcode
add_shortcode('acervo_cultural', 'acervo_cultural_shortcode');
