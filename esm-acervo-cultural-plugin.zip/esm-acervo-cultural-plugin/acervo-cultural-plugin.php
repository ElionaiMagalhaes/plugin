<?php
/*
Plugin Name: Controle de Acervo Cultural
Description: Plugin para gerenciar obras de acervos culturais.
Version: 1.0
Author: Elionai de Souza Magalhães
*/




require_once plugin_dir_path(__FILE__) . 'includes/class-acervo-cultural-plugin.php';


// Adiciona um menu no painel de administração
function acervo_cultural_plugin_menu() {
    add_menu_page(
        'Acervo Cultural',
        'Acervo Cultural',
        'manage_options',
        'acervo-cultural-settings',
        'acervo_cultural_settings_page',
        'dashicons-art', // Ícone do menu
        30 // Posição do menu
    );
}
add_action('admin_menu', 'acervo_cultural_plugin_menu');

// Função para exibir o conteúdo da página de configurações
function acervo_cultural_settings_page() {
    // Verifica se o usuário atual tem permissão para acessar a página
    if (!current_user_can('manage_options')) {
        wp_die(__('Você não tem permissão para acessar esta página.'));
    }
    ?>
    <div class="wrap">
        <h2>Configurações do Acervo Cultural</h2>
        <!-- Aqui você pode adicionar o conteúdo da página -->
        <p>Esta é a página de configurações do plugin Acervo Cultural.</p>
    </div>
    <?php
}
