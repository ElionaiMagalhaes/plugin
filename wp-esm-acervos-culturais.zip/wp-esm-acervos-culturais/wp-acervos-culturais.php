<?php
/**
 * Plugin Name: Controle de Acervos Culturais
 * Description: Plugin para controle de acervos culturais.
 * Version: 1.1
 * Author: Elionai de S Magalhães
 */

// Criação do Custom Post Type
function acervos_culturais_cpt() {
    register_post_type('acervo_cultural', [
        'public' => true,
        'label'  => 'Acervos Culturais',
        'supports' => ['title', 'editor'],
        'show_in_rest' => true, // Habilita a API REST para esse CPT
    ]);
}
add_action('init', 'acervos_culturais_cpt');


// Adiciona a página do plugin no admin
function acervos_culturais_admin_page() {
    add_menu_page(
        'Acervos Culturais',
        'Acervos Culturais',
        'manage_options',
        'acervos_culturais',
        'acervos_culturais_admin_page_html'
    );
}


add_action('admin_menu', 'acervos_culturais_admin_page');

// HTML da página do admin
function acervos_culturais_admin_page_html() {
    echo '<div id="app"></div>'; // Div para a aplicação VueJS
}


// Enqueue scripts e styles
function acervos_culturais_scripts() {
    wp_enqueue_script('vue-app', plugins_url('/vue-app/dist/build.js', __FILE__), [], '1.0.0', true);
}
add_action('admin_enqueue_scripts', 'acervos_culturais_scripts');
