<?php

// Adiciona ação para inicializar a API REST
add_action('rest_api_init', function () {
    // Registra a rota para obter as obras
    register_rest_route('acervos/v1', '/obras', array(
        'methods' => 'GET',
        'callback' => 'get_obras',
    ));

    // Registra a rota para criar uma obra
    register_rest_route('acervos/v1', '/obras', array(
        'methods' => 'POST',
        'callback' => 'create_obra',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        }
    ));

    // Registra a rota para atualizar uma obra
    register_rest_route('acervos/v1', '/obras/(?P<id>\d+)', array(
        'methods' => 'PUT',
        'callback' => 'update_obra',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        }
    ));

    // Registra a rota para deletar uma obra
    register_rest_route('acervos/v1', '/obras/(?P<id>\d+)', array(
        'methods' => 'DELETE',
        'callback' => 'delete_obra',
        'permission_callback' => function () {
            return current_user_can('delete_posts');
        }
    ));
});

// Função para obter as obras
function get_obras($data) {
    $posts = get_posts(array(
        'post_type' => 'acervo_cultural',
        'posts_per_page' => -1,
    ));

    $obras = array();
    foreach ($posts as $post) {
        $obras[] = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'description' => $post->post_content,
            // Adicione mais campos conforme necessário
        );
    }

    return new WP_REST_Response($obras, 200);
}

// Função para criar uma obra
function create_obra($request) {
    $parameters = $request->get_json_params();
    $post_id = wp_insert_post(array(
        'post_title' => $parameters['title'],
        'post_content' => $parameters['description'],
        'post_type' => 'acervo_cultural',
        'post_status' => 'publish',
        // Adicione mais campos conforme necessário
    ));

    return new WP_REST_Response(array('id' => $post_id), 200);
}

// Função para atualizar uma obra
function update_obra($request) {
    $parameters = $request->get_json_params();
    $post_id = wp_update_post(array(
        'ID' => $request['id'],
        'post_title' => $parameters['title'],
        'post_content' => $parameters['description'],
        // Adicione mais campos conforme necessário
    ));

    return new WP_REST_Response(array('id' => $post_id), 200);
}

// Função para deletar uma obra
function delete_obra($request) {
    $post_id = wp_delete_post($request['id'], true);

    if ($post_id) {
        return new WP_REST_Response(array('message' => 'Obra deletada com sucesso'), 200);
    } else {
        return new WP_REST_Response(array('message' => 'Falha ao deletar obra'), 404);
    }
}

/**
 * Explicação
 * 
 * Rotas Personalizadas: 
 *  Registra rotas na API REST do WordPress para realizar operações 
 *  CRUD nas obras do acervo cultural.
 * 
 * Callbacks: 
 * 
 *  Funções que são chamadas quando as rotas correspondentes são acessadas. 
 *  Elas manipulam a lógica para cada operação (GET, POST, PUT, DELETE).
 * 
 * Permissões: 
 *  
 *  Utiliza permission_callback para verificar se o usuário tem permissões adequadas para realizar 
 *  operações de criação, atualização e exclusão.
 * 
*/
