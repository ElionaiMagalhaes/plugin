<?php
/*
Plugin Name: Controle para obras de acervo cultural
Plugin URI: http://selecaobolsa.com/
Description: Controle básico para obras de acervos culturais.
Version: 3.0
Author: Elionai Magalhães
Author URI: http://selecaobolsa.com/
License: GPL2
*/

// Registro do Custom Post Type
function acervo_cultural_register_post_type() {

    $labels = array(
        'name'               => 'Obras',
        'singular_name'      => 'Obra',
        'add_new'            => 'Adicionar Nova',
        'add_new_item'       => 'Adicionar Nova Obra',
        'edit_item'          => 'Editar Obra',
        'new_item'           => 'Nova Obra',
        'all_items'          => 'Todas as Obras',
        'view_item'          => 'Ver Obra',
        'search_items'       => 'Buscar Obras',
        'not_found'          => 'Nenhuma obra encontrada',
        'not_found_in_trash' => 'Nenhuma obra encontrada na lixeira',
        'menu_name'          => 'Obras'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'obra'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'show_in_rest'       => true // Para suporte ao Gutenberg
    );

    register_post_type('obra', $args);
}

add_action('init', 'acervo_cultural_register_post_type');

// Meta boxes para os detalhes da obra
function acervo_cultural_add_meta_boxes() {
    add_meta_box(
        'acervo_cultural_obra_details',
        'Detalhes da Obra',
        'acervo_cultural_obra_details_callback',
        'obra',
        'normal',
        'high'
    );
}

add_action('add_meta_boxes', 'acervo_cultural_add_meta_boxes');

function acervo_cultural_obra_details_callback($post) {
    // Busca os valores salvos
    $descricao = get_post_meta($post->ID, 'descricao', true);
    $data_criacao = get_post_meta($post->ID, 'data_criacao', true);
    $materiais = get_post_meta($post->ID, 'materiais', true);
    $autor = get_post_meta($post->ID, 'autor', true);
    $localizacao = get_post_meta($post->ID, 'localizacao', true);

    // Adiciona um campo nonce para verificação de segurança
    wp_nonce_field('acervo_cultural_save_postdata', 'acervo_cultural_meta_box_nonce');

    // Campos do formulário
    echo '<label for="descricao">Descrição:</label>';
    echo '<textarea id="descricao" name="descricao" rows="4" cols="50">' . esc_attr($descricao) . '</textarea><br /><br />';

    echo '<label for="data_criacao">Data de Criação:</label>';
    echo '<input type="date" id="data_criacao" name="data_criacao" value="' . esc_attr($data_criacao) . '" /><br /><br />';

    echo '<label for="materiais">Materiais Utilizados:</label>';
    echo '<input type="text" id="materiais" name="materiais" value="' . esc_attr($materiais) . '" /><br /><br />';

    echo '<label for="autor">Autor:</label>';
    echo '<input type="text" id="autor" name="autor" value="' . esc_attr($autor) . '" /><br /><br />';

    echo '<label for="localizacao">Localização da Obra:</label>';
    echo '<input type="text" id="localizacao" name="localizacao" value="' . esc_attr($localizacao) . '" /><br /><br />';
}


// Salvar os dados dos meta boxes
function acervo_cultural_save_postdata($post_id) {
    // Verifica se nonce está definido e é válido
    if (!isset($_POST['acervo_cultural_meta_box_nonce']) || !wp_verify_nonce($_POST['acervo_cultural_meta_box_nonce'], 'acervo_cultural_save_postdata')) {
        return;
    }

    // Se este é um autosave, nosso formulário não foi submetido, então não queremos fazer nada
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Verifica a permissão do usuário
    if (isset($_POST['post_type']) && 'obra' == $_POST['post_type']) {
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
    } else {
        return;
    }

    // Agora podemos salvar os dados

    // Sanitiza e salva a descrição
    if (isset($_POST['descricao'])) {
        update_post_meta($post_id, 'descricao', sanitize_textarea_field($_POST['descricao']));
    }

    // Salva a data de criação
    if (isset($_POST['data_criacao'])) {
        update_post_meta($post_id, 'data_criacao', sanitize_text_field($_POST['data_criacao']));
    }

    // Salva os materiais utilizados
    if (isset($_POST['materiais'])) {
        update_post_meta($post_id, 'materiais', sanitize_text_field($_POST['materiais']));
    }

    // Salva o autor
    if (isset($_POST['autor'])) {
        update_post_meta($post_id, 'autor', sanitize_text_field($_POST['autor']));
    }

    // Salva a localização da obra
    if (isset($_POST['localizacao'])) {
        update_post_meta($post_id, 'localizacao', sanitize_text_field($_POST['localizacao']));
    }
}

add_action('save_post', 'acervo_cultural_save_postdata');


function acervo_cultural_add_admin_page() {
    add_menu_page(
        'Acervo Cultural', // Título da página
        'Acervo Cultural', // Título do menu
        'manage_options', // Capacidade necessária para ver o menu
        'acervo-cultural-admin', // Slug do menu
        'acervo_cultural_admin_page', // Função que renderiza a página do plugin
        'dashicons-admin-customizer', // Ícone do menu
        110 // Posição no menu
    );
}

add_action('admin_menu', 'acervo_cultural_add_admin_page');

function acervo_cultural_admin_page() {
    ?>
    <div id="acervo-cultural-app"></div>
    <?php
}

